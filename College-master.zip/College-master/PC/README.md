# PC
**Programs of college 1st year subject PC for easy sharing.**  Feel free to use them. I have used non-optimal coding practices at times, just so that it becomes easier for someone not well-versed in better practices to understand. I try to update it whenever I get time.  
If you want, you can suggest improvements -> akashbhalotia.unofficial@gmail.com
