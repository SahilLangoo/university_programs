Since this is Java course and not DS, I have tried to write programs which are easier to implement and more intuitive,   
rather than better in terms of complexity. 
