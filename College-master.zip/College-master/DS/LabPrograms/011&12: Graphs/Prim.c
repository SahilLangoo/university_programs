/*
 * Prim's algorithm for Minimum Spanning Tree.
 * O(N*M), which can be O(N^3) in the worst case, in case of a dense graph.
 *
 * It can also be done in O(MlogN), but for the sake of simplicity,
 * I have done it in O(N*M).
 *
 * Assuming at-least one spanning tree exists.
 */

//created by Whiplash99
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

struct list //adjacency list
{
    int v,weight;
    struct list *next;
} **edge=NULL;
void init(int N) //initialises the adjacency list
{
    for(int i=0;i<N;i++)
        edge[i]=NULL;
}
void addEdge(int u, int v, int weight) //inserts an edge into the graph
{
    struct list *tmp=(struct list*)malloc(sizeof(struct list));
    tmp->v=v;
    tmp->weight=weight;
    tmp->next=NULL;

    if(edge[u]==NULL)
        edge[u]=tmp;
    else
    {
        tmp->next=edge[u];
        edge[u]=tmp;
    }
}
int next(int selected[],int N) //returns the next smallest edge from selected set to the not-selected set
{
    int min=INT_MAX,u=-1,v=-1;
    for(int i=0;i<N;i++)
    {
        if(selected[i])
        {
            struct list *tmp=edge[i];
            while (tmp!=NULL)
            {
                if(!selected[tmp->v]&&tmp->weight<min)
                {
                    min=tmp->weight;
                    u=i;
                    v=tmp->v;
                }
                tmp=tmp->next;
            }
        }
    }
    selected[v]=1;
    printf("%d - %d\n",(u+1),(v+1));
    return min;
}
void MST(int N) //finding the MST
{
    int selected[N],ans=0;
    for(int i=0;i<N;i++) selected[i]=0;

    selected[0]=1;
    for(int i=0;i<N-1;i++)
        ans+=next(selected,N);

    printf("\nThe weight is: %d\n\n",ans);
}
int main() //main method
{
    int N=0,M,u,v,weight;

    printf("Enter the number of vertices and the number of edge\n");
    scanf("%d%d",&N,&M);

    edge=(struct list**)malloc(N*sizeof(struct list*));
    init(N);

    for(int i=0;i<M;i++)
    {
        printf("Enter an edge\n");
        scanf("%d%d%d",&u,&v,&weight);
        u--;v--;

        addEdge(u,v,weight);
        addEdge(v,u,weight);
    }

    printf("The spanning tree is:\n");
    MST(N);

    return 0;
}
